package com.github.awsjava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwsJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwsJavaApplication.class, args);
	}

}
