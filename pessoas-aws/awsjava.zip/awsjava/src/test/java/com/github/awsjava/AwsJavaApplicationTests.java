package com.github.awsjava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AwsJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
